import { EventEmitter } from 'events';

export type LogLevel = 'off' | 'error' | 'warn' | 'info' | 'debug' | 'trace';
export type WispExtension = 'udp' | 'motd' | 'wispnet';
export type PortRange = number | `${number}-${number}` | [number, number];

export interface LogRecord {
  level: 'error' | 'warn' | 'info' | 'debug' | 'trace';
  target: string;
  message: string;
}

export interface Socks5Options {
  /** Proxy host. Default `"127.0.0.1"`. */
  host?: string;
  port: number;
  /** Username/password auth (RFC 1929). Omit both for no auth. */
  username?: string;
  password?: string;
  /** Let the proxy resolve hostnames (socks5h). Default `false`. */
  remoteDns?: boolean;
  /** UDP can't go over SOCKS5 CONNECT: `"block"` (default) refuses it, `"direct"` sends it from this server. */
  udp?: 'block' | 'direct';
  /** Connect timeout through the proxy in ms. Default `10000`. */
  timeout?: number;
}

export interface EpoxyServerOptions {
  // ---- listener ----
  /** Interface to bind. Default `"127.0.0.1"`. Use `"0.0.0.0"` to listen on all interfaces. */
  host?: string;
  /** Port to bind. Default `4000`. Use `0` for a random free port. */
  port?: number;
  /** Listen on a Unix socket at this path instead of TCP. */
  unixSocket?: string;
  /** Serve over TLS (wss://). Each value is a file path or PEM text. */
  tls?: { cert: string | Buffer; key: string | Buffer } | null | false;
  /** Socket transport. Default `"websocket"`. */
  transport?: 'websocket' | 'lengthDelimitedLe';
  /** URL prefix the Wisp endpoint is served under, e.g. `"/wisp"`. Default: root. */
  prefix?: string;
  /** Server log level. Default `"info"`. */
  logLevel?: LogLevel;
  /** Tokio runtime flavor. Default `"multithread"`. */
  runtime?: 'multithread' | 'singlethread';
  /** Resolve and connect to IPv6 upstream addresses. Default `false`. */
  resolveIpv6?: boolean;
  /** TCP_NODELAY on client sockets. Default `true`. */
  tcpNodelay?: boolean;
  /** Trust `X-Real-IP` / `X-Forwarded-For` (enable behind a reverse proxy). Default `false`. */
  useRealIpHeaders?: boolean;
  /** Body sent to plain HTTP (non-WebSocket) requests. Default `":3"`. */
  nonWsResponse?: string;
  /** Max incoming WebSocket message size in bytes. Default `65536`. */
  maxMessageSize?: number;
  /**
   * Stats endpoint. A path string (e.g. `"/stats"`) or `true` serves JSON stats on the
   * main listener; `{ host, port }` or `{ unixSocket }` starts a separate stats listener.
   */
  stats?: string | boolean | { path: string } | { host?: string; port: number } | { unixSocket: string } | null;

  // ---- wisp ----
  /** Enable Wisp v2 (extensions, auth). Default `true`. */
  wispV2?: boolean;
  /** Allow legacy wsproxy connections. Default `true`. */
  allowWsproxy?: boolean;
  /** Buffer size (packets) advertised to clients. Default `128`. */
  bufferSize?: number;
  /** Wisp v2 extensions to advertise. Default `["udp", "motd"]`. */
  extensions?: WispExtension[];
  /** MOTD extension message. */
  motd?: string;
  /** Require authentication (Wisp v2 only). */
  auth?:
    | { type?: 'password'; users: Record<string, string>; required?: boolean }
    | { type?: 'certificate'; keys: Array<string | Buffer>; required?: boolean }
    | null
    | false;

  // ---- streams / access control ----
  /** Allow UDP streams. Default `true`. */
  allowUdp?: boolean;
  /** Allow nonstandard legacy wsproxy UDP. Default `false`. */
  allowWsproxyUdp?: boolean;
  /** DNS servers to use. Default: system resolver config. */
  dnsServers?: string[];
  /** Allow connecting to raw IP addresses. Default `true`. */
  allowDirectIp?: boolean;
  /** Allow connecting to loopback addresses. Default `true` — set `false` for public servers! */
  allowLoopback?: boolean;
  /** Allow multicast addresses. Default `true`. */
  allowMulticast?: boolean;
  /** Allow globally routable addresses. Default `true`. */
  allowGlobal?: boolean;
  /** Allow private / non-global addresses (LAN etc.). Default `true` — set `false` for public servers! */
  allowNonGlobal?: boolean;
  /** Host regex allow/block lists (strings are regex sources). */
  allowHosts?: Array<string | RegExp>;
  blockHosts?: Array<string | RegExp>;
  allowTcpHosts?: Array<string | RegExp>;
  blockTcpHosts?: Array<string | RegExp>;
  allowUdpHosts?: Array<string | RegExp>;
  blockUdpHosts?: Array<string | RegExp>;
  /** Port allow/block lists. */
  allowPorts?: PortRange[];
  blockPorts?: PortRange[];
  /** Read buffer size for upstream TCP sockets in bytes. Default `131072`. */
  streamBufferSize?: number;
  /** TCP_NODELAY on upstream sockets. Default `true`. */
  streamTcpNodelay?: boolean;

  // ---- upstream proxy ----
  /**
   * Route outgoing TCP streams through a SOCKS5 proxy.
   * - `"socks5://user:pass@host:1080"`: hostnames resolved here, then the IP is sent to the proxy.
   * - `"socks5h://host:1080"`: hostnames are resolved by the proxy (remote DNS).
   * UDP streams are blocked while a proxy is set unless `udp: "direct"`.
   */
  socks5?: string | Socks5Options | null | false;
  /** Alias of `socks5`. */
  proxy?: string | Socks5Options | null | false;

  // ---- node integration ----
  /** Keep the Node process alive while the server is running. Default `true`. */
  keepAlive?: boolean;
  /** Receive server logs instead of printing them to stderr. */
  onLog?: (record: LogRecord) => void;
  /**
   * Raw epoxy-server config (snake_case, same schema as upstream config.toml), or a path
   * to a JSON file. Deep-merged over everything above.
   */
  config?: Record<string, any> | string;
}

export interface AddressInfo {
  address: string;
  port?: number;
  family?: 'IPv4' | 'IPv6';
  tls: boolean;
  unix: boolean;
  /** Client URL, e.g. `ws://127.0.0.1:4000/` (not set for Unix sockets). */
  url?: string;
  statsAddress?: string;
}

export interface ServerStats {
  clients: Record<
    string,
    {
      client_type: string;
      streams: Record<string, { stream_type: string; requested: string; resolved: string }>;
    }
  >;
  config: Record<string, any> | string;
  memory: NodeJS.MemoryUsage;
}

export declare class EpoxyServer extends EventEmitter {
  constructor(options?: EpoxyServerOptions);
  options: EpoxyServerOptions;
  /** The full config object that will be sent to the native server. */
  readonly config: Record<string, any>;
  readonly listening: boolean;
  listen(): Promise<AddressInfo>;
  start(): Promise<AddressInfo>;
  close(): Promise<void>;
  stop(): Promise<void>;
  restart(newOptions?: Partial<EpoxyServerOptions>): Promise<AddressInfo>;
  address(): AddressInfo | null;
  stats(): Promise<ServerStats>;

  on(event: 'listening', listener: (address: AddressInfo) => void): this;
  on(event: 'close', listener: () => void): this;
  on(event: 'log', listener: (record: LogRecord) => void): this;
  on(event: string | symbol, listener: (...args: any[]) => void): this;
}

export declare function createServer(options?: EpoxyServerOptions): EpoxyServer;
export declare function startServer(options?: EpoxyServerOptions): Promise<EpoxyServer>;
export declare function defaultConfig(): Record<string, any>;
export declare function buildConfig(options?: EpoxyServerOptions): Record<string, any>;
export declare function version(): string;

declare const _default: {
  EpoxyServer: typeof EpoxyServer;
  createServer: typeof createServer;
  startServer: typeof startServer;
  defaultConfig: typeof defaultConfig;
  buildConfig: typeof buildConfig;
  version: typeof version;
};
export default _default;
