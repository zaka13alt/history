//! Node.js bindings for epoxy-server.
//!
//! The upstream server keeps its configuration in process-wide statics (`CONFIG`,
//! `RESOLVER`, ...). Instead of `lazy_static` values read from the command line, this
//! crate stores them in [`Swappable`] cells that are filled in by `start()` from a JSON
//! config supplied by JavaScript. Only one server can run per process at a time, but it
//! can be stopped and started again with a different configuration.
#![allow(unexpected_cfgs)]
#![allow(clippy::all)]

use std::{
	collections::HashMap,
	net::IpAddr,
	ops::Deref,
	ptr,
	sync::{
		atomic::{AtomicPtr, Ordering},
		Mutex as StdMutex, OnceLock,
	},
	thread::JoinHandle,
	time::Duration,
};

use anyhow::Context;
use config::{validate_config_cache, Cli, Config, ConfigFormat, RuntimeFlavor, StatsEndpoint};
use handle::{handle_wisp, handle_wsproxy, wisp::wispnet::handle_wispnet};
use hickory_resolver::{
	config::{NameServerConfigGroup, ResolverConfig},
	name_server::TokioConnectionProvider,
	system_conf::read_system_conf,
	TokioResolver,
};
use lazy_static::lazy_static;
use listener::ServerListener;
use log::{error, info, trace, warn};
use napi::{
	bindgen_prelude::*,
	threadsafe_function::{ErrorStrategy, ThreadSafeCallContext, ThreadsafeFunction, ThreadsafeFunctionCallMode},
	Env, JsFunction, JsUnknown, ValueType,
};
use napi_derive::napi;
use route::{route_stats, ServerRouteResult};
use stats::generate_stats;
use tokio::{runtime, sync::{oneshot, Mutex}};
use uuid::Uuid;
use wisp_mux::packet::ConnectPacket;

pub mod config;
mod handle;
mod listener;
mod route;
mod socks5;
mod stats;
mod stream;
mod upgrade;
mod util_chain;
mod util_map_err;

// ---------------------------------------------------------------------------
// Swappable global cell
// ---------------------------------------------------------------------------

/// A `'static` cell that can be replaced between server runs. Old values are leaked on
/// purpose so that `&'static` references handed out by `Deref` stay valid; a config is a
/// few KB and is only replaced on restart, so this is negligible.
pub struct Swappable<T: 'static>(AtomicPtr<T>);

impl<T: 'static> Swappable<T> {
	pub const fn new() -> Self {
		Self(AtomicPtr::new(ptr::null_mut()))
	}

	pub fn set(&self, value: T) {
		self.0.store(Box::into_raw(Box::new(value)), Ordering::SeqCst);
	}

	pub fn is_set(&self) -> bool {
		!self.0.load(Ordering::SeqCst).is_null()
	}
}

impl<T: 'static> Deref for Swappable<T> {
	type Target = T;
	fn deref(&self) -> &T {
		let ptr = self.0.load(Ordering::SeqCst);
		assert!(!ptr.is_null(), "epoxy-server: global accessed before server start");
		// SAFETY: pointers stored here come from Box::into_raw and are never freed.
		unsafe { &*ptr }
	}
}

// ---------------------------------------------------------------------------
// Globals expected by the upstream server modules
// ---------------------------------------------------------------------------

#[doc(hidden)]
type Client = (Mutex<HashMap<Uuid, (ConnectPacket, ConnectPacket)>>, String);

#[derive(Debug)]
pub enum Resolver {
	Hickory(TokioResolver),
	System,
}

impl Resolver {
	pub async fn resolve(&self, host: String) -> anyhow::Result<Box<dyn Iterator<Item = IpAddr>>> {
		match self {
			Self::Hickory(resolver) => Ok(Box::new(resolver.lookup_ip(host).await?.into_iter())),
			Self::System => Ok(Box::new(
				tokio::net::lookup_host(host + ":0").await?.map(|x| x.ip()),
			)),
		}
	}

	pub fn clear_cache(&self) {
		match self {
			Self::Hickory(resolver) => resolver.clear_cache(),
			Self::System => {}
		}
	}

	fn from_config(config: &Config) -> Self {
		if config.stream.dns_servers.is_empty() {
			if let Ok((cfg, opts)) = read_system_conf() {
				Resolver::Hickory(
					TokioResolver::builder_with_config(cfg, TokioConnectionProvider::default())
						.with_options(opts)
						.build(),
				)
			} else {
				warn!("unable to read system dns configuration. using system dns resolver with no caching");
				Resolver::System
			}
		} else {
			Resolver::Hickory(
				TokioResolver::builder_with_config(
					ResolverConfig::from_parts(
						None,
						Vec::new(),
						NameServerConfigGroup::from_ips_clear(&config.stream.dns_servers, 53, true),
					),
					TokioConnectionProvider::default(),
				)
				.build(),
			)
		}
	}
}

lazy_static! {
	/// Config files are always JSON when coming from Node.
	pub static ref CLI: Cli = Cli { config: None, format: ConfigFormat::Json, default_config: false };
	pub static ref CLIENTS: Mutex<HashMap<String, Client>> = Mutex::new(HashMap::new());
}

pub static CONFIG: Swappable<Config> = Swappable::new();
pub static RESOLVER: Swappable<Resolver> = Swappable::new();

// ---------------------------------------------------------------------------
// Logging (stderr by default, or forwarded to a JS callback)
// ---------------------------------------------------------------------------

#[napi(object)]
#[derive(Clone)]
pub struct LogRecord {
	pub level: String,
	pub target: String,
	pub message: String,
}

static LOG_CALLBACK: StdMutex<Option<ThreadsafeFunction<LogRecord, ErrorStrategy::Fatal>>> = StdMutex::new(None);
static LOGGER_INSTALLED: OnceLock<()> = OnceLock::new();

struct NodeLogger;

impl log::Log for NodeLogger {
	fn enabled(&self, metadata: &log::Metadata) -> bool {
		metadata.level() <= log::max_level()
	}

	fn log(&self, record: &log::Record) {
		if !self.enabled(record.metadata()) {
			return;
		}
		let cb = LOG_CALLBACK.lock().ok().and_then(|x| x.clone());
		match cb {
			Some(cb) => {
				cb.call(
					LogRecord {
						level: record.level().as_str().to_lowercase(),
						target: record.target().to_string(),
						message: record.args().to_string(),
					},
					ThreadsafeFunctionCallMode::NonBlocking,
				);
			}
			None => eprintln!("[epoxy-server {} {}] {}", record.level(), record.target(), record.args()),
		}
	}

	fn flush(&self) {}
}

fn install_logger() {
	LOGGER_INSTALLED.get_or_init(|| {
		let _ = log::set_boxed_logger(Box::new(NodeLogger));
	});
}

/// Route all server logs to `callback({ level, target, message })`. Pass `null` to go
/// back to printing on stderr.
#[napi(ts_args_type = "callback: ((record: LogRecord) => void) | null | undefined")]
pub fn set_logger(env: Env, callback: JsUnknown) -> Result<()> {
	install_logger();
	let tsfn = match callback.get_type()? {
		ValueType::Function => {
			// SAFETY: type checked above
			let cb: JsFunction = unsafe { callback.cast() };
			let mut tsfn: ThreadsafeFunction<LogRecord, ErrorStrategy::Fatal> = cb
				.create_threadsafe_function(0, |ctx: ThreadSafeCallContext<LogRecord>| Ok(vec![ctx.value]))?;
			// don't let the logger keep the event loop alive on its own
			tsfn.unref(&env)?;
			Some(tsfn)
		}
		ValueType::Null | ValueType::Undefined => None,
		_ => return Err(Error::new(Status::InvalidArg, "setLogger expects a function or null")),
	};
	*LOG_CALLBACK.lock().unwrap() = tsfn;
	Ok(())
}

// ---------------------------------------------------------------------------
// Server lifecycle
// ---------------------------------------------------------------------------

struct Running {
	shutdown: oneshot::Sender<()>,
	thread: JoinHandle<()>,
	address: String,
	stats_address: Option<String>,
}

static RUNNING: StdMutex<Option<Running>> = StdMutex::new(None);

#[napi(object)]
pub struct StartResult {
	/// Address the Wisp server actually bound to (e.g. `127.0.0.1:4000` or a socket path).
	pub address: String,
	/// Address of the separate stats server, if one was configured.
	pub stats_address: Option<String>,
}

async fn run_server(ready: oneshot::Sender<anyhow::Result<StartResult>>, shutdown: oneshot::Receiver<()>) {
	let setup = async {
		validate_config_cache().await?;

		let listener = ServerListener::new(&CONFIG.server.bind)
			.await
			.with_context(|| format!("failed to bind to address {}", CONFIG.server.bind.1))?;

		let stats_listener = match CONFIG.server.stats_endpoint.as_ref().and_then(StatsEndpoint::get_bindaddr) {
			Some(bind) => Some(
				ServerListener::new(&bind)
					.await
					.with_context(|| format!("failed to bind to address {} for stats server", bind.1))?,
			),
			None => None,
		};

		anyhow::Ok((listener, stats_listener))
	};

	let (listener, stats_listener) = match setup.await {
		Ok(x) => x,
		Err(e) => {
			let _ = ready.send(Err(e));
			return;
		}
	};

	let address = listener.local_addr().unwrap_or_else(|| CONFIG.server.bind.1.clone());
	let stats_address = stats_listener.as_ref().and_then(|x| x.local_addr());

	info!(
		"listening on {} with runtime flavor {:?} and socket transport {:?}",
		address, CONFIG.server.runtime, CONFIG.server.transport
	);
	trace!("CONFIG: {:#?}", &*CONFIG);

	if ready.send(Ok(StartResult { address, stats_address })).is_err() {
		return;
	}

	if let Some(stats_listener) = stats_listener {
		tokio::spawn(listen_stats(stats_listener));
	}

	tokio::select! {
		_ = listen_wisp(listener) => {}
		_ = shutdown => info!("shutting down"),
	}
}

async fn listen_stats(mut stats_listener: ServerListener) {
	loop {
		match stats_listener.accept().await {
			Ok((stream, _)) => {
				tokio::spawn(async move {
					if let Err(e) = Box::pin(route_stats(stream)).await {
						error!("error while routing stats client: {:?}", e);
					}
				});
			}
			Err(e) => error!("error while accepting stats client: {:?}", e),
		}
	}
}

async fn listen_wisp(mut listener: ServerListener) {
	let stats_endpoint = CONFIG.server.stats_endpoint.as_ref().and_then(StatsEndpoint::get_endpoint);

	loop {
		let stats_endpoint = stats_endpoint.clone();
		match listener.accept().await {
			Ok((stream, client_id)) => {
				tokio::spawn(async move {
					let res = Box::pin(route::route(stream, stats_endpoint, move |stream, maybe_ip| {
						let client_id = if let Some(ip) = maybe_ip {
							format!("{client_id} ({ip})")
						} else {
							client_id
						};
						trace!("routed {:?}: {}", client_id, stream);
						handle_stream(stream, client_id);
					}))
					.await;

					if let Err(e) = res {
						error!("error while routing client: {:?}", e);
					}
				});
			}
			Err(e) => {
				error!("error while accepting client: {:?}", e);
				// avoid a hot loop on persistent errors (e.g. EMFILE)
				tokio::time::sleep(Duration::from_millis(10)).await;
			}
		}
	}
}

fn handle_stream(stream: ServerRouteResult, id: String) {
	tokio::spawn(async move {
		CLIENTS
			.lock()
			.await
			.insert(id.clone(), (Mutex::new(HashMap::new()), format!("{stream}")));
		let res = match stream {
			ServerRouteResult::Wisp { stream, has_ws_protocol } => {
				Box::pin(handle_wisp(stream, has_ws_protocol, id.clone())).await
			}
			ServerRouteResult::Wispnet { stream } => Box::pin(handle_wispnet(stream, id.clone())).await,
			ServerRouteResult::WsProxy { stream, path, udp } => {
				Box::pin(handle_wsproxy(stream, id.clone(), path, udp)).await
			}
		};
		if let Err(e) = res {
			error!("error while handling client: {:?}", e);
		}
		CLIENTS.lock().await.remove(&id)
	});
}

fn to_napi_err(e: anyhow::Error) -> Error {
	Error::new(Status::GenericFailure, format!("{e:#}"))
}

/// Start the server with a full epoxy-server config (JSON string, same schema as the
/// upstream TOML config). Resolves once the listener is bound.
#[napi]
pub async fn start(config_json: String) -> Result<StartResult> {
	let mut config: Config = serde_json::from_str(&config_json)
		.context("failed to parse config")
		.map_err(to_napi_err)?;

	{
		let running = RUNNING.lock().unwrap();
		if running.is_some() {
			return Err(Error::new(Status::GenericFailure, "epoxy-server is already running; call stop() first"));
		}
	}

	install_logger();
	log::set_max_level(config.server.log_level);

	let flavor = match config.server.runtime {
		RuntimeFlavor::SingleThread => RuntimeFlavor::SingleThread,
		RuntimeFlavor::ThreadPerCore => {
			warn!("runtime \"threadpercore\" is not supported in the Node.js bindings, using \"multithread\"");
			config.server.runtime = RuntimeFlavor::MultiThread;
			RuntimeFlavor::MultiThread
		}
		_ => RuntimeFlavor::MultiThread,
	};

	RESOLVER.set(Resolver::from_config(&config));
	CONFIG.set(config);
	CLIENTS.lock().await.clear();

	let (ready_tx, ready_rx) = oneshot::channel();
	let (shutdown_tx, shutdown_rx) = oneshot::channel();

	let thread = std::thread::Builder::new()
		.name("epoxy-server".into())
		.spawn(move || {
			let mut builder = match flavor {
				RuntimeFlavor::SingleThread => runtime::Builder::new_current_thread(),
				_ => runtime::Builder::new_multi_thread(),
			};
			let rt = match builder.enable_all().thread_name("epoxy-server-worker").build() {
				Ok(rt) => rt,
				Err(e) => {
					let _ = ready_tx.send(Err(anyhow::anyhow!(e).context("failed to build tokio runtime")));
					return;
				}
			};
			rt.block_on(run_server(ready_tx, shutdown_rx));
			// drops every connection task
			rt.shutdown_timeout(Duration::from_secs(2));
		})
		.map_err(|e| Error::new(Status::GenericFailure, format!("failed to spawn server thread: {e}")))?;

	let result = match ready_rx.await {
		Ok(Ok(r)) => r,
		Ok(Err(e)) => {
			let _ = thread.join();
			return Err(to_napi_err(e));
		}
		Err(_) => {
			let _ = thread.join();
			return Err(Error::new(Status::GenericFailure, "epoxy-server thread exited unexpectedly"));
		}
	};

	let mut running = RUNNING.lock().unwrap();
	if running.is_some() {
		// lost a race with a concurrent start()
		let _ = shutdown_tx.send(());
		return Err(Error::new(Status::GenericFailure, "epoxy-server is already running; call stop() first"));
	}
	*running = Some(Running {
		shutdown: shutdown_tx,
		thread,
		address: result.address.clone(),
		stats_address: result.stats_address.clone(),
	});

	Ok(result)
}

/// Stop the running server and close all client connections. No-op if not running.
#[napi]
pub async fn stop() -> Result<()> {
	let running = RUNNING.lock().unwrap().take();
	if let Some(running) = running {
		let _ = running.shutdown.send(());
		tokio::task::spawn_blocking(move || {
			let _ = running.thread.join();
		})
		.await
		.map_err(|e| Error::new(Status::GenericFailure, e.to_string()))?;
		CLIENTS.lock().await.clear();
	}
	Ok(())
}

/// Whether the server is currently running.
#[napi]
pub fn is_running() -> bool {
	RUNNING.lock().unwrap().is_some()
}

/// Bound address of the running server, or null.
#[napi]
pub fn address() -> Option<StartResult> {
	RUNNING.lock().unwrap().as_ref().map(|r| StartResult {
		address: r.address.clone(),
		stats_address: r.stats_address.clone(),
	})
}

/// JSON stats: active config plus connected clients and their open streams.
#[napi(js_name = "stats")]
pub async fn get_stats() -> Result<String> {
	if !CONFIG.is_set() {
		return Err(Error::new(Status::GenericFailure, "epoxy-server has not been started"));
	}
	stats::generate_stats().await.map_err(to_napi_err)
}

/// The upstream default config, as a JSON string.
#[napi]
pub fn default_config() -> Result<String> {
	serde_json::to_string_pretty(&Config::default()).map_err(|e| Error::new(Status::GenericFailure, e.to_string()))
}

/// Version string of the compiled server.
#[napi]
pub fn version() -> String {
	format!("{} ({})", env!("CARGO_PKG_VERSION"), config::VERSION_STRING)
}
