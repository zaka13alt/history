//! Minimal async SOCKS5 client (RFC 1928 CONNECT + RFC 1929 username/password auth),
//! used to route outgoing Wisp TCP streams through an upstream SOCKS5 proxy.

use std::{
	net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr},
	time::Duration,
};

use anyhow::{bail, Context};
use tokio::{
	io::{AsyncReadExt, AsyncWriteExt},
	net::TcpStream,
	time::timeout,
};

use crate::config::Socks5Config;

const VERSION: u8 = 0x05;
const AUTH_NONE: u8 = 0x00;
const AUTH_USERPASS: u8 = 0x02;
const AUTH_NO_ACCEPTABLE: u8 = 0xff;
const CMD_CONNECT: u8 = 0x01;
const ATYP_IPV4: u8 = 0x01;
const ATYP_DOMAIN: u8 = 0x03;
const ATYP_IPV6: u8 = 0x04;

fn reply_error(code: u8) -> &'static str {
	match code {
		0x01 => "general SOCKS server failure",
		0x02 => "connection not allowed by ruleset",
		0x03 => "network unreachable",
		0x04 => "host unreachable",
		0x05 => "connection refused",
		0x06 => "TTL expired",
		0x07 => "command not supported",
		0x08 => "address type not supported",
		_ => "unknown error",
	}
}

/// Opens a TCP connection to `host:port` through the configured SOCKS5 proxy.
/// `host` may be an IP address or (for remote DNS) a hostname.
pub async fn connect(cfg: &Socks5Config, host: &str, port: u16) -> anyhow::Result<TcpStream> {
	let dur = Duration::from_millis(cfg.timeout_ms.max(1));
	timeout(dur, connect_inner(cfg, host, port))
		.await
		.with_context(|| format!("timed out after {}ms connecting through socks5 proxy {}", cfg.timeout_ms, cfg.address))?
}

async fn connect_inner(cfg: &Socks5Config, host: &str, port: u16) -> anyhow::Result<TcpStream> {
	let mut stream = TcpStream::connect(&cfg.address)
		.await
		.with_context(|| format!("failed to connect to socks5 proxy {}", cfg.address))?;

	// --- method negotiation ---
	let has_creds = cfg.username.is_some() || cfg.password.is_some();
	if has_creds {
		stream.write_all(&[VERSION, 2, AUTH_NONE, AUTH_USERPASS]).await?;
	} else {
		stream.write_all(&[VERSION, 1, AUTH_NONE]).await?;
	}

	let mut resp = [0u8; 2];
	stream.read_exact(&mut resp).await.context("socks5 proxy closed during greeting")?;
	if resp[0] != VERSION {
		bail!("socks5 proxy replied with version {} (is it really a SOCKS5 proxy?)", resp[0]);
	}
	match resp[1] {
		AUTH_NONE => {}
		AUTH_USERPASS if has_creds => {
			let user = cfg.username.as_deref().unwrap_or("").as_bytes();
			let pass = cfg.password.as_deref().unwrap_or("").as_bytes();
			if user.len() > 255 || pass.len() > 255 {
				bail!("socks5 username and password must be at most 255 bytes");
			}
			let mut buf = Vec::with_capacity(3 + user.len() + pass.len());
			buf.push(0x01);
			buf.push(user.len() as u8);
			buf.extend_from_slice(user);
			buf.push(pass.len() as u8);
			buf.extend_from_slice(pass);
			stream.write_all(&buf).await?;

			let mut auth = [0u8; 2];
			stream.read_exact(&mut auth).await.context("socks5 proxy closed during authentication")?;
			if auth[1] != 0x00 {
				bail!("socks5 proxy rejected the username/password");
			}
		}
		AUTH_USERPASS => bail!("socks5 proxy requires a username and password, but none are configured"),
		AUTH_NO_ACCEPTABLE => bail!("socks5 proxy accepted none of our auth methods (check username/password)"),
		other => bail!("socks5 proxy chose unsupported auth method 0x{other:02x}"),
	}

	// --- CONNECT request ---
	let mut req = vec![VERSION, CMD_CONNECT, 0x00];
	match host.parse::<IpAddr>() {
		Ok(IpAddr::V4(ip)) => {
			req.push(ATYP_IPV4);
			req.extend_from_slice(&ip.octets());
		}
		Ok(IpAddr::V6(ip)) => {
			req.push(ATYP_IPV6);
			req.extend_from_slice(&ip.octets());
		}
		Err(_) => {
			let name = host.as_bytes();
			if name.is_empty() || name.len() > 255 {
				bail!("hostname length must be 1-255 bytes for socks5");
			}
			req.push(ATYP_DOMAIN);
			req.push(name.len() as u8);
			req.extend_from_slice(name);
		}
	}
	req.extend_from_slice(&port.to_be_bytes());
	stream.write_all(&req).await?;

	// --- reply ---
	let mut head = [0u8; 4];
	stream.read_exact(&mut head).await.context("socks5 proxy closed before replying to CONNECT")?;
	if head[0] != VERSION {
		bail!("invalid socks5 reply version {}", head[0]);
	}
	if head[1] != 0x00 {
		bail!("socks5 proxy could not connect to {host}:{port}: {}", reply_error(head[1]));
	}
	// consume the bound address so the stream starts at the payload
	let _bound: SocketAddr = match head[3] {
		ATYP_IPV4 => {
			let mut b = [0u8; 6];
			stream.read_exact(&mut b).await?;
			SocketAddr::new(Ipv4Addr::new(b[0], b[1], b[2], b[3]).into(), u16::from_be_bytes([b[4], b[5]]))
		}
		ATYP_IPV6 => {
			let mut b = [0u8; 18];
			stream.read_exact(&mut b).await?;
			let mut ip = [0u8; 16];
			ip.copy_from_slice(&b[..16]);
			SocketAddr::new(Ipv6Addr::from(ip).into(), u16::from_be_bytes([b[16], b[17]]))
		}
		ATYP_DOMAIN => {
			let mut len = [0u8; 1];
			stream.read_exact(&mut len).await?;
			let mut b = vec![0u8; len[0] as usize + 2];
			stream.read_exact(&mut b).await?;
			SocketAddr::new(Ipv4Addr::UNSPECIFIED.into(), 0)
		}
		other => bail!("socks5 proxy replied with unknown address type 0x{other:02x}"),
	};

	Ok(stream)
}
