use std::process::Command;

fn main() {
	napi_build::setup();

	// The upstream server embeds version info via vergen. Emit equivalents without
	// needing a git checkout so the crate builds from the npm tarball.
	let rustc = std::env::var("RUSTC").unwrap_or_else(|_| "rustc".into());
	let out = Command::new(&rustc).arg("-vV").output().ok().and_then(|o| String::from_utf8(o.stdout).ok()).unwrap_or_default();
	let field = |name: &str| {
		out.lines()
			.find_map(|l| l.strip_prefix(&format!("{name}: ")))
			.unwrap_or("unknown")
			.to_string()
	};
	println!("cargo:rustc-env=VERGEN_RUSTC_SEMVER={}", field("release"));
	println!("cargo:rustc-env=VERGEN_RUSTC_HOST_TRIPLE={}", field("host"));
	println!("cargo:rustc-env=VERGEN_GIT_SHA={}", include_str!("UPSTREAM_COMMIT").trim());
	println!("cargo:rustc-env=VERGEN_GIT_DIRTY=false");
	println!("cargo:rerun-if-changed=UPSTREAM_COMMIT");
}
