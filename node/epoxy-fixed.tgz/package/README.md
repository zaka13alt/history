# epoxy-server-node

Node.js bindings for [epoxy-server](https://github.com/MercuryWorkshop/epoxy-tls/tree/multiplexed/server), Mercury Workshop's Rust [Wisp](https://github.com/MercuryWorkshop/wisp-protocol) server. The Rust server is compiled into a native addon (N-API) and runs on its own threads, so you get the full Rust performance while starting, stopping and configuring it from JavaScript.

```js
const { startServer } = require('epoxy-server-node');

const server = await startServer({ host: '0.0.0.0', port: 8080, prefix: '/wisp' });
console.log(server.address().url); // ws://0.0.0.0:8080/wisp/
```

## Install

```sh
npm install epoxy-server-node
```

Prebuilt binaries ship for Linux (x64/arm64, glibc and musl/Alpine) and macOS (x64/arm64). On any other platform the install step compiles from the bundled Rust source, which needs [Rust](https://rustup.rs). Windows is not supported by epoxy-server itself (use WSL).

## Usage

```js
import { EpoxyServer } from 'epoxy-server-node';

const server = new EpoxyServer({
  host: '0.0.0.0',
  port: 8080,
  prefix: '/wisp',
  logLevel: 'info',

  // recommended for anything public-facing:
  allowLoopback: false,   // block 127.0.0.1 / ::1
  allowNonGlobal: false,  // block LAN / private ranges
  blockPorts: [25, '6000-6100'],
});

server.on('log', ({ level, message }) => console.log(`[${level}] ${message}`));

const addr = await server.listen();
console.log(`listening on ${addr.url}`);

console.log(await server.stats());       // connected clients + open streams
await server.restart({ port: 9090 });    // stop, merge new options, start again
await server.close();
```

### Routing through a SOCKS5 proxy

Like wisp-server-python's `--proxy`, outgoing TCP streams can go through a SOCKS5 proxy (Tor, a residential proxy, an SSH `-D` tunnel, ...):

```js
new EpoxyServer({ port: 8080, socks5: 'socks5://user:pass@127.0.0.1:1080' });  // with password
new EpoxyServer({ port: 8080, socks5: 'socks5h://127.0.0.1:9050' });            // no password, proxy resolves DNS (Tor)
new EpoxyServer({
  port: 8080,
  socks5: { host: '10.0.0.5', port: 1080, username: 'user', password: 'pass', remoteDns: false, udp: 'block', timeout: 10000 },
});
```

- `socks5://` resolves hostnames on this server, checks them against your rules (loopback, private ranges, block lists), then sends the IP to the proxy.
- `socks5h://` (or `remoteDns: true`) sends the hostname to the proxy unresolved, which is what you want for Tor. Hostname-based block lists still apply, but loopback/private IP checks only apply to clients that connect to a raw IP.
- SOCKS5 CONNECT can't carry UDP, so UDP streams are refused while a proxy is set, the same as wisp-server-python. Set `udp: 'direct'` to send UDP straight from this server instead.
- If the proxy is down or rejects the login, the Wisp client gets "unreachable" for that stream and a `warn` log explains why.
- Percent-encode special characters in URL passwords (`p@ss` becomes `p%40ss`), or use the object form.

CLI: `npx epoxy-server --proxy socks5h://127.0.0.1:9050` (or the `SOCKS5_PROXY` env var), plus `--proxy-udp direct` if you want UDP to bypass it.

In raw config form (snake_case) it lives at `stream.socks5`:
`{ "address": "127.0.0.1:1080", "username": "u", "password": "p", "remote_dns": false, "udp": "block", "timeout_ms": 10000 }`.

### CLI

```sh
npx epoxy-server --host 0.0.0.0 --port 8080 --prefix /wisp --no-loopback --no-private
npx epoxy-server --help
```

### With an existing HTTP server (Express, Fastify, ...)

epoxy-server owns its socket, so run it on its own port (or Unix socket) and forward
WebSocket upgrades to it from your reverse proxy (nginx, Caddy) or from Node with a
proxy such as `http-proxy`:

```js
const httpProxy = require('http-proxy');
const proxy = httpProxy.createProxyServer({ target: 'ws://127.0.0.1:4000', ws: true });
httpServer.on('upgrade', (req, socket, head) => {
  if (req.url.startsWith('/wisp/')) proxy.ws(req, socket, head);
});
```

Set `useRealIpHeaders: true` when it sits behind a proxy so client IPs are logged correctly.

## Options

| Option | Default | Description |
| --- | --- | --- |
| `host` | `"127.0.0.1"` | Interface to bind. `"0.0.0.0"` / `"::"` for all. |
| `port` | `4000` | Port. `0` picks a free port (see `address().port`). |
| `unixSocket` | | Listen on a Unix socket path instead of TCP. |
| `tls` | | `{ cert, key }` as file paths or PEM text. Serves `wss://`. |
| `prefix` | `""` | URL prefix, e.g. `"/wisp"`. |
| `transport` | `"websocket"` | Or `"lengthDelimitedLe"` (raw length-prefixed frames). |
| `logLevel` | `"info"` | `off` `error` `warn` `info` `debug` `trace`. |
| `onLog` | | `(record) => void`. Same as listening to the `log` event. Without either, logs go to stderr. |
| `runtime` | `"multithread"` | Or `"singlethread"`. |
| `stats` | | `"/stats"` (or `true`) serves JSON stats on the same port; `{ host, port }` starts a separate stats listener. |
| `wispV2` | `true` | Enable Wisp v2 (extensions + auth). |
| `extensions` | `["udp","motd"]` | Wisp v2 extensions: `udp`, `motd`, `wispnet`. |
| `motd` | | MOTD message. |
| `auth` | | `{ users: { name: "pass" } }` for password auth, or `{ type: "certificate", keys: [pem...] }`. `required` defaults to `true`. |
| `bufferSize` | `128` | Packet buffer advertised to clients. |
| `allowWsproxy` | `true` | Allow legacy wsproxy connections. |
| `allowUdp` | `true` | Allow UDP streams. |
| `allowWsproxyUdp` | `false` | Legacy wsproxy UDP. |
| `allowDirectIp` | `true` | Allow connecting to raw IP addresses. |
| `allowLoopback` | `true` | Allow loopback addresses. **Turn off for public servers.** |
| `allowNonGlobal` | `true` | Allow private/LAN addresses. **Turn off for public servers.** |
| `allowGlobal` / `allowMulticast` | `true` | Allow global / multicast addresses. |
| `allowHosts` / `blockHosts` | `[]` | Host regex allow/block lists (strings or `RegExp`). Also `allowTcpHosts`, `blockTcpHosts`, `allowUdpHosts`, `blockUdpHosts`. |
| `allowPorts` / `blockPorts` | `[]` | Ports: `443`, `"8000-9000"` or `[8000, 9000]`. |
| `dnsServers` | system | DNS server IPs. |
| `resolveIpv6` | `false` | Connect to IPv6 upstreams. |
| `tcpNodelay` / `streamTcpNodelay` | `true` | `TCP_NODELAY` on client / upstream sockets. |
| `streamBufferSize` | `131072` | Upstream read buffer in bytes. |
| `useRealIpHeaders` | `false` | Trust `X-Real-IP` / `X-Forwarded-For`. |
| `nonWsResponse` | `":3"` | Body returned for plain HTTP requests. |
| `maxMessageSize` | `65536` | Max WebSocket message size. |
| `socks5` (alias `proxy`) | | Route TCP through a SOCKS5 proxy. URL (`socks5://user:pass@host:port`, `socks5h://...`) or `{ host, port, username, password, remoteDns, udp, timeout }`. See above. |
| `keepAlive` | `true` | Keep the Node process alive while listening. |
| `config` | | Raw upstream config (snake_case, same schema as epoxy-server's `config.toml`) or a path to a JSON file. Merged over everything else, so any upstream setting is reachable. |

`server.config` shows the exact config that will be sent to Rust, and `defaultConfig()` returns the upstream defaults.

## API

- `new EpoxyServer(options)` / `createServer(options)`, then `listen()`; or `startServer(options)` to do both.
- `server.listen()` resolves with `{ address, port, family, url, tls, unix, statsAddress }` once the socket is bound. Rejects on bind or config errors.
- `server.close()` stops listening and drops every client.
- `server.restart(newOptions?)`.
- `server.address()`, `server.listening`, `server.stats()`.
- Events: `listening`, `close`, `log`.
- `defaultConfig()`, `buildConfig(options)`, `version()`.

Only one server can run per process, because epoxy-server keeps its config in process-wide globals. You can stop it and start it again with different options as often as you like.

## Building and publishing

```sh
npm run build            # compile for this machine -> build/epoxy-server.node
npm test                 # end-to-end test (proxies a TCP echo over Wisp)
npm run build:prebuild   # compile into prebuilds/<platform>-<arch>/ for publishing
npm publish
```

To ship binaries for every platform, push this folder to a GitHub repo, add an `NPM_TOKEN` secret, and push a tag (`git tag v2.0.0 && git push --tags`). `.github/workflows/release.yml` builds Linux x64/arm64 (glibc + musl) and macOS x64/arm64, runs the tests, and publishes.

`npm publish` refuses to run if `prebuilds/` is empty, so you don't accidentally publish a package that needs Rust. Set `EPOXY_ALLOW_SOURCE_ONLY=1` to do it anyway.

Optional upstream features: `node scripts/build.js --features speed-limit,twisp`.

## How it works

`native/src` is the upstream `server/src` with `main.rs` replaced by `lib.rs`. The upstream's command-line/`lazy_static` globals are replaced with cells that `start()` fills from the JSON config, which is what makes stop/restart possible. A small SOCKS5 client (`native/src/socks5.rs`, RFC 1928/1929) was added for the proxy option. The other changes are small: config validation returns errors instead of panicking, the jemalloc allocator and memory stats are dropped (stats use `process.memoryUsage()` instead), and the SIGUSR1 stats handler is removed because Node uses that signal for its inspector. Upstream commit: see `native/UPSTREAM_COMMIT`.

## License

AGPL-3.0, same as epoxy-server. If you run a modified version as a network service, the AGPL requires you to offer its source to users.
