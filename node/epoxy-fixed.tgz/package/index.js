'use strict';

const { EventEmitter } = require('events');
const { buildConfig } = require('./lib/config');

let native = null;
function binding() {
  if (!native) native = require('./lib/binding').load();
  return native;
}

// The Rust server keeps its config in process-wide globals, so only one instance can
// be listening at a time. We track which JS object owns it.
let owner = null;

class EpoxyServer extends EventEmitter {
  /**
   * @param {import('./index').EpoxyServerOptions} [options]
   */
  constructor(options = {}) {
    super();
    this.options = { ...options };
    this._keepAlive = null;
    this._address = null;
    this._starting = null;
  }

  /** The full epoxy-server config that will be sent to the native server. */
  get config() {
    return buildConfig(this.options);
  }

  get listening() {
    return owner === this && binding().isRunning();
  }

  /**
   * Start listening. Resolves with the bound address info.
   * @returns {Promise<import('./index').AddressInfo>}
   */
  async listen() {
    if (this._starting) return this._starting;
    if (owner === this && binding().isRunning()) return this._address;
    if (owner && owner !== this && binding().isRunning()) {
      throw new Error('epoxy-server: another EpoxyServer is already running in this process; close() it first');
    }

    const config = buildConfig(this.options);
    const nb = binding();

    if (typeof this.options.onLog === 'function') {
      nb.setLogger((rec) => {
        try {
          this.options.onLog(rec);
        } catch (_) {
          /* never let a user callback crash the logger */
        }
      });
    } else if (this.listenerCount('log') > 0) {
      nb.setLogger((rec) => this.emit('log', rec));
    } else {
      nb.setLogger(null);
    }

    this._starting = (async () => {
      try {
        const res = await nb.start(JSON.stringify(config));
        owner = this;
        this._address = parseAddress(res, config);
        if (this.options.keepAlive !== false) {
          // the server runs on its own native threads; keep Node's event loop alive
          this._keepAlive = setInterval(() => {}, 1 << 30);
        }
        this.emit('listening', this._address);
        return this._address;
      } finally {
        this._starting = null;
      }
    })();
    return this._starting;
  }

  /** Alias of listen(). */
  start() {
    return this.listen();
  }

  /** Stop the server and drop all client connections. */
  async close() {
    if (this._starting) await this._starting.catch(() => {});
    if (owner !== this) return;
    await binding().stop();
    owner = null;
    this._address = null;
    if (this._keepAlive) clearInterval(this._keepAlive);
    this._keepAlive = null;
    this.emit('close');
  }

  /** Alias of close(). */
  stop() {
    return this.close();
  }

  /** Stop and start again, optionally with new options merged in. */
  async restart(newOptions) {
    await this.close();
    if (newOptions) this.options = { ...this.options, ...newOptions };
    return this.listen();
  }

  /** Bound address, or null when not listening. */
  address() {
    return owner === this ? this._address : null;
  }

  /**
   * Live stats: connected clients, their open streams, and the active config.
   * @returns {Promise<import('./index').ServerStats>}
   */
  async stats() {
    if (owner !== this) throw new Error('epoxy-server: server is not running');
    const raw = JSON.parse(await binding().stats());
    let config = raw.config;
    try {
      config = JSON.parse(raw.config);
    } catch (_) {
      /* leave as string */
    }
    return { clients: raw.clients, config, memory: process.memoryUsage() };
  }
}

function parseAddress(res, config) {
  const [type] = config.server.bind;
  const info = {
    address: res.address,
    family: undefined,
    port: undefined,
    tls: type.startsWith('tls'),
    unix: type.endsWith('unix'),
    statsAddress: res.statsAddress || undefined,
  };
  if (!info.unix) {
    const m = /^\[?(.*?)\]?:(\d+)$/.exec(res.address);
    if (m) {
      info.address = m[1];
      info.port = Number(m[2]);
      info.family = m[1].includes(':') ? 'IPv6' : 'IPv4';
    }
  }
  const scheme = info.tls ? 'wss' : 'ws';
  if (!info.unix) {
    const host = info.family === 'IPv6' ? `[${info.address}]` : info.address;
    const prefix = (config.wisp && config.wisp.prefix) || '';
    info.url = `${scheme}://${host}:${info.port}${prefix}/`;
  }
  return info;
}

/**
 * Create a server (not started yet).
 * @param {import('./index').EpoxyServerOptions} [options]
 */
function createServer(options) {
  return new EpoxyServer(options);
}

/**
 * Create and start a server in one call.
 * @param {import('./index').EpoxyServerOptions} [options]
 */
async function startServer(options) {
  const server = new EpoxyServer(options);
  await server.listen();
  return server;
}

/** Upstream default config (snake_case object). */
function defaultConfig() {
  return JSON.parse(binding().defaultConfig());
}

/** Version of the compiled native server. */
function version() {
  return binding().version();
}

module.exports = {
  EpoxyServer,
  createServer,
  startServer,
  defaultConfig,
  buildConfig,
  version,
};
module.exports.default = module.exports;
