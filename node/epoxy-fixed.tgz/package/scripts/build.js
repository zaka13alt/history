#!/usr/bin/env node
'use strict';

// Compiles the Rust addon with cargo and copies it to build/epoxy-server.node
// (or prebuilds/<tag>/epoxy-server.node with --prebuild).
//
//   node scripts/build.js                 release build for this machine
//   node scripts/build.js --debug         debug build
//   node scripts/build.js --prebuild      put output in prebuilds/<platform>-<arch>
//   node scripts/build.js --target x86_64-unknown-linux-gnu --tag linux-x64
//   node scripts/build.js --features speed-limit,twisp
//   node scripts/build.js --zig           use cargo-zigbuild (cross / old-glibc builds)

const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { platformTag } = require('../lib/binding');

const root = path.join(__dirname, '..');
const nativeDir = path.join(root, 'native');

const argv = process.argv.slice(2);
const flag = (name) => argv.includes(name);
const value = (name) => {
  const i = argv.indexOf(name);
  return i !== -1 ? argv[i + 1] : undefined;
};

const debug = flag('--debug');
const prebuild = flag('--prebuild');
const zig = flag('--zig');
const target = value('--target');
const features = value('--features');
const tag = value('--tag') || platformTag();

const cargo = process.env.CARGO || 'cargo';
const check = spawnSync(cargo, ['--version'], { stdio: 'ignore' });
if (check.status !== 0) {
  console.error('epoxy-server: cargo not found. Install Rust from https://rustup.rs and try again.');
  process.exit(1);
}

const args = [zig ? 'zigbuild' : 'build', '--manifest-path', path.join(nativeDir, 'Cargo.toml'), '-p', 'epoxy-server-node'];
if (!debug) args.push('--release');
if (target) args.push('--target', target);
if (features) args.push('--features', features);

console.log(`> ${cargo} ${args.join(' ')}`);
const env = { ...process.env };
// musl cdylibs must link the C runtime dynamically to be loadable by node
if (target && target.includes('musl')) {
  env.RUSTFLAGS = `${env.RUSTFLAGS || ''} -C target-feature=-crt-static`.trim();
}
const res = spawnSync(cargo, args, { stdio: 'inherit', env });
if (res.status !== 0) process.exit(res.status || 1);

const profile = debug ? 'debug' : 'release';
const targetDir = process.env.CARGO_TARGET_DIR ? path.resolve(process.env.CARGO_TARGET_DIR) : path.join(nativeDir, 'target');
const outDir = target ? path.join(targetDir, target.replace(/\.\d+(\.\d+)?$/, ''), profile) : path.join(targetDir, profile);

const os = target || process.platform;
const libName = /darwin|apple/.test(os)
  ? 'libepoxy_server_node.dylib'
  : /win32|windows/.test(os)
    ? 'epoxy_server_node.dll'
    : 'libepoxy_server_node.so';

const src = path.join(outDir, libName);
if (!fs.existsSync(src)) {
  console.error(`epoxy-server: build finished but ${src} was not found`);
  process.exit(1);
}

const destDir = prebuild ? path.join(root, 'prebuilds', tag) : path.join(root, 'build');
fs.mkdirSync(destDir, { recursive: true });
const dest = path.join(destDir, 'epoxy-server.node');
fs.copyFileSync(src, dest);
console.log(`epoxy-server: wrote ${path.relative(root, dest)}`);
