'use strict';

// postinstall: use a prebuilt binary when one ships for this platform; otherwise try to
// compile from the bundled Rust source. Never fails the install - a clear error is thrown
// at require() time instead if no binary is available.

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { platformTag } = require('../lib/binding');

const root = path.join(__dirname, '..');
const tag = platformTag();
const prebuilt = path.join(root, 'prebuilds', tag, 'epoxy-server.node');
const local = path.join(root, 'build', 'epoxy-server.node');

if (process.env.EPOXY_SERVER_SKIP_BUILD) process.exit(0);

if (fs.existsSync(prebuilt) || fs.existsSync(local)) {
  if (!process.env.EPOXY_SERVER_FORCE_BUILD) process.exit(0);
}

if (process.platform === 'win32') {
  console.warn('epoxy-server: Windows is not supported by epoxy-server (it relies on Unix sockets/ptys). Use WSL.');
  process.exit(0);
}

const hasCargo = spawnSync(process.env.CARGO || 'cargo', ['--version'], { stdio: 'ignore' }).status === 0;
if (!hasCargo) {
  console.warn(
    `epoxy-server: no prebuilt binary for ${tag} and Rust is not installed.\n` +
      '  Install Rust (https://rustup.rs) and run `npm rebuild epoxy-server-node`.'
  );
  process.exit(0);
}

console.log(`epoxy-server: no prebuilt binary for ${tag}, compiling from source (this takes a few minutes)...`);
const res = spawnSync(process.execPath, [path.join(__dirname, 'build.js')], { stdio: 'inherit', cwd: root });
if (res.status !== 0) {
  console.warn('epoxy-server: source build failed; see output above.');
}
process.exit(0);
