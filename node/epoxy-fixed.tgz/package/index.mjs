import cjs from './index.js';

export const { EpoxyServer, createServer, startServer, defaultConfig, buildConfig, version } = cjs;
export default cjs;
